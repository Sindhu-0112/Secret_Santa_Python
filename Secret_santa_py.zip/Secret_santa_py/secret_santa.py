import csv
import random
import os
from typing import List, Dict

def load_employees(file_path: str) -> List[Dict[str, str]]:
    """Loads employee data from a CSV file and ensures proper header handling."""
    try:
        with open(file_path, mode='r', encoding='utf-8') as file:
            reader = csv.reader(file)
            headers = next(reader, None)  # Read the header row

            required_fields = {"Employee_Name", "Employee_EmailID"}
            if not headers or set(headers) != required_fields:
                raise ValueError(f"Invalid CSV header format. Expected fields: {required_fields}")

            name_index = headers.index("Employee_Name")
            email_index = headers.index("Employee_EmailID")

            return [
                {"name": row[name_index], "email": row[email_index]}
                for row in reader if len(row) > max(name_index, email_index)
            ]
    except FileNotFoundError:
        raise FileNotFoundError(f"File not found: {file_path}")
    except Exception as e:
        raise RuntimeError(f"Error loading employees: {e}")

def assign_secret_santa(employees: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Assigns each employee a unique Secret Santa."""
    if not employees:
        raise ValueError("Employee list cannot be empty.")

    available_recipients = employees.copy()
    random.shuffle(available_recipients)
    assignments = []

    for giver in employees:
        for recipient in available_recipients:
            if giver["email"] != recipient["email"]:
                assignments.append({
                    "Employee_Name": giver["name"],
                    "Employee_EmailID": giver["email"],
                    "Secret_Child_Name": recipient["name"],
                    "Secret_Child_EmailID": recipient["email"]
                })
                available_recipients.remove(recipient)
                break

    if len(assignments) != len(employees):
        return assign_secret_santa(employees)  # Retry assignment if necessary

    return assignments

def save_assignments(assignments: List[Dict[str, str]], output_file: str):
    """Saves the Secret Santa assignments to a CSV file."""
    try:
        with open(output_file, mode='w', newline='', encoding='utf-8') as file:
            fieldnames = ["Employee_Name", "Employee_EmailID", "Secret_Child_Name", "Secret_Child_EmailID"]
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(assignments)
        print(f"Assignments saved successfully to {output_file}")
    except Exception as e:
        raise RuntimeError(f"Error saving assignments: {e}")

if __name__ == "__main__":
    # Calculate absolute paths dynamically based on the script's location
    script_path = os.path.realpath(__file__)  # Path to the script
    parent_folder_path = os.path.dirname((script_path))  # Parent folder of the script (Secret_santa_py)
    input_folder_path = os.path.join(parent_folder_path, 'input')
    output_folder_path = os.path.join(parent_folder_path, 'output')

    # Construct the full paths for input and output files
    input_file = os.path.join(input_folder_path, 'Employee.csv')
    output_file = os.path.join(output_folder_path, 'secret_santa_output.csv')

    try:
        employees = load_employees(input_file)
        assignments = assign_secret_santa(employees)
        save_assignments(assignments, output_file)
    except Exception as e:
        print(f"Error: {e}")
