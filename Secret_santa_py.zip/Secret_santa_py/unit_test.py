import unittest
import os
import csv
from secret_santa import load_employees, assign_secret_santa, save_assignments

class TestSecretSanta(unittest.TestCase):
    def setUp(self):

        script_path = os.path.realpath(__file__)  # Path to the script
        parent_folder_path = os.path.dirname((script_path))  # Parent folder of the script (Secret_santa_py)

        """Sets up temporary files for testing."""
        # Construct the full paths for input and output files
        self.test_folder = os.path.join(parent_folder_path, 'test')
        self.test_file = os.path.join(self.test_folder, 'test_employees.csv')
        self.test_output_file = os.path.join(self.test_folder, 'test_output.csv')
        
        with open(self.test_file, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(["Employee_Name", "Employee_EmailID"])
            writer.writerows([
                ["Alice", "alice@example.com"],
                ["Bob", "bob@example.com"],
                ["Charlie", "charlie@example.com"]
            ])


    # def tearDown(self):
    #     """Removes test files after execution."""
    #     if os.path.exists(self.test_file):
    #         os.remove(self.test_file)
    #     if os.path.exists(self.test_output_file):
    #         os.remove(self.test_output_file)


    def test_load_employees(self):
        """Test if employees are loaded correctly from a CSV."""
        employees = load_employees(self.test_file)
        self.assertEqual(len(employees), 3)
        self.assertEqual(employees[0]["name"], "Alice")
        self.assertEqual(employees[1]["email"], "bob@example.com")

    def test_load_employees_invalid_headers(self):
        """Test error handling when headers are incorrect."""
        with open(self.test_file, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(["Wrong_Name", "Wrong_EmailID"])  # Incorrect headers
            writer.writerows([["Alice", "alice@example.com"], ["Bob", "bob@example.com"]])

        with self.assertRaises(RuntimeError) as cm:
            load_employees(self.test_file)
        
        self.assertIn("Invalid CSV header format", str(cm.exception))

    def test_assign_secret_santa(self):
        """Test that Secret Santa assignments are unique and complete."""
        employees = load_employees(self.test_file)
        assignments = assign_secret_santa(employees)
        assigned_names = {pair["Secret_Child_Name"] for pair in assignments}
        self.assertEqual(len(assigned_names), len(employees))

    def test_assign_secret_santa_empty_list(self):
        """Test handling of an empty employee list."""
        with self.assertRaises(ValueError):
            assign_secret_santa([])

    def test_save_assignments(self):
        """Test saving assignments to a file."""
        employees = load_employees(self.test_file)
        assignments = assign_secret_santa(employees)
        save_assignments(assignments, self.test_output_file)
        
        self.assertTrue(os.path.exists(self.test_output_file))

    def test_load_employees_file_not_found(self):
        """Test file not found error handling."""
        with self.assertRaises(FileNotFoundError):
            load_employees("non_existent_file.csv")

if __name__ == "__main__":
    unittest.main()
